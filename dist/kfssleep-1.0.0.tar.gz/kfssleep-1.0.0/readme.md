---
Topic: "KFSsleep Library"
Author: "구FS"
---
<link href="./doc_templates/md_style.css" rel="stylesheet"></link>
<body>

# <p style="text-align: center;">KFSsleep Library</p>
<br>
<br>

- [1. General](#1-general)
- [2. Installation](#2-installation)

## 1. General

This library is a collection of miscellaneouns sleep functions that turned out to be quite useful to have while creating my other projects.  
For further documentation, read the provided docstrings or feel free to send me a message. I'm also always happy about sugggestions and tips.

## 2. Installation

You can install this library from Pypi with `pip install KFSsleep`.

</body>